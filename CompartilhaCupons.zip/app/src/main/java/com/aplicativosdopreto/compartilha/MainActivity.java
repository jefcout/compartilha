package com.aplicativosdopreto.compartilha;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

import com.aplicativosdopreto.compartilha.domain.util.LibraryClass;
import com.firebase.client.Firebase;




public class MainActivity extends AppCompatActivity {

    public ProgressBar progress;
    private WebView webView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        try {
            WebView myWebView = (WebView) findViewById(R.id.webview);
            setWebViewClient(myWebView);
            myWebView.getSettings().setJavaScriptEnabled(true);
            myWebView.loadUrl("http://jeffersoncoutinho.com.br/mobile/");
            progress = (ProgressBar)findViewById(R.id.progress);
        }catch (Exception e){
            e.getMessage();

        }

        webView.buildDrawingCache();
/*        FloatingActionButton fab = (FloatingActionButton)findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                
            }
        });*/
        /*FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //logout(view);
            }
        });*/
    }




    
    @Override
    public void onBackPressed() {
        if(webView.canGoBack()){
            webView.goBack();
        }
        super.onBackPressed();
    }



    public void setWebViewClient(final WebView webView) {
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                progress.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                progress.setVisibility(View.INVISIBLE);
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
                try {
                    Intent it = new Intent(MainActivity.this, ErrorActivity.class);
                    startActivity(it);
                } catch (Exception e) {
                    e.getMessage();

                }

            }
        });
        this.webView = webView;
    }





    public void logout(View view){
        Firebase firebase = LibraryClass.getFirebase();
        firebase.unauth();

        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if(id == R.id.menusair){
            finish();
        }

        if(id == R.id.logout){
            Firebase firebase = LibraryClass.getFirebase();
            firebase.unauth();
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            finish();
        }

        return super.onOptionsItemSelected(item);
    }
}